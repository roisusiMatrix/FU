import { FC } from 'react';

const Mfe{new-name} :FC = ({
}) =>{
    return <div>This is the {new-name} MFE</div>
}


export default Mfe{new-name}
