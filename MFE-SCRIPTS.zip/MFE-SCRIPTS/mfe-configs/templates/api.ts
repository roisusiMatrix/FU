
//bla bla

//bla bla 2

export const {new-name}Service = ()=>{
    const baseApi = ""
}
