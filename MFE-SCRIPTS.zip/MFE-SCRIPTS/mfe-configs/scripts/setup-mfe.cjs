#!/usr/bin/env node

const chalk = require('chalk');
const fs = require('fs');
const path = require('path');
const {execSync} = require('child_process');
const readline = require('readline');

// Configuration files to copy
const CONFIG_FILES = [
    '.dockerignore',
    '.gitignore',
    '.prettierrc',
    'Dockerfile',
    'Dockerfile-local',
    'README.md',
    'package.base.json'
];

// Directories to create
const DIRECTORIES = [
    'src',
    'src/api',
    'src/assets',
    'src/components',
    'src/components/containers',
    'src/components/main',
    'src/components/side',
    'src/components/titles',
    'src/data',
    'src/enums',
    'src/hooks',
    'src/infrastructure',
    'src/interfaces',
    'src/models',
    'src/types',
    'src/utils'
];

// Function to check if a command exists globally
const isCommandAvailable = (command) => {
    try {
        execSync(`command -v ${command}`, {stdio: 'ignore'});
        return true;
    } catch {
        return false;
    }
};

// Function to clean the current directory
const cleanDirectory = () => {
    console.log(chalk.yellow('Cleaning the current directory...'));
    const files = fs.readdirSync(process.cwd());
    files.forEach((file) => {
        const filePath = path.join(process.cwd(), file);
        if (fs.lstatSync(filePath).isDirectory()) {
            fs.rmSync(filePath, {recursive: true, force: true});
        } else {
            fs.unlinkSync(filePath);
        }
    });
    console.log(chalk.green('Directory cleaned.'));
};

// Function to display a beautiful square banner
const displayBanner = (version) => {
    const bannerWidth = 60;
    const border = '═'.repeat(bannerWidth - 2);
    const emptyLine = `║${' '.repeat(bannerWidth - 2)}║`;
    const title = `MFE CREATE SETUP ver ${version}`;
    const paddedTitle = title.padStart(
        Math.floor((bannerWidth - title.length) / 2) + title.length
    );

    console.log(chalk.green(`╔${border}╗`));
    console.log(chalk.green(emptyLine));
    console.log(chalk.green(`║${paddedTitle}${' '.repeat(bannerWidth - paddedTitle.length - 2)}║`));
    console.log(chalk.green(emptyLine));
    console.log(chalk.green(`╚${border}╝`));
};


// Function to merge dependencies into package.json
const mergePackageJson = (templatesDir) => {
    const packageJsonPath = path.join(process.cwd(), 'package.json');
    const basePackageJsonPath = path.join(templatesDir, 'package.base.json');

    if (!fs.existsSync(packageJsonPath)) {
        console.error(chalk.red('package.json not found in the project root.'));
        process.exit(1);
    }

    if (!fs.existsSync(basePackageJsonPath)) {
        console.error(chalk.red('package.base.json not found in the templates directory.'));
        process.exit(1);
    }

    const currentPackageJson = JSON.parse(fs.readFileSync(packageJsonPath, 'utf-8'));
    const basePackageJson = JSON.parse(fs.readFileSync(basePackageJsonPath, 'utf-8'));

    // Add extend field
    currentPackageJson.extends = './package.base.json';

    // Merge dependencies
    currentPackageJson.dependencies = {
        ...basePackageJson.dependencies,
        ...currentPackageJson.dependencies,
    };

    // Merge devDependencies
    currentPackageJson.devDependencies = {
        ...basePackageJson.devDependencies,
        ...currentPackageJson.devDependencies,
    };

    fs.writeFileSync(packageJsonPath, JSON.stringify(currentPackageJson, null, 2));
    console.log(chalk.green('Merged dependencies into package.json and added "extends".'));
};

// Function to create a new Vite project
const createViteProject = () => {
    console.log(chalk.yellow('Setting up a new Vite React-TS project...'));
    try {
        execSync('pnpm create vite . --template react-ts --force', {stdio: 'inherit'});
        console.log(chalk.green('Vite React-TS project setup complete.'));
    } catch (error) {
        console.error(chalk.red('Failed to set up Vite project:'), error.message);
        process.exit(1);
    }
};

// Function to initialize Git
const initializeGit = () => {
    console.log(chalk.yellow('Initializing Git repository...'));
    try {
        execSync('git init', {stdio: 'inherit'});
        console.log(chalk.green('Git repository initialized.'));
    } catch (error) {
        console.error(chalk.red('Failed to initialize Git:', error.message));
        process.exit(1);
    }
};

// Function to set up Husky
const setupHusky = () => {
    console.log(chalk.yellow('Setting up Husky...'));
    try {
        execSync('pnpm add -D husky', {stdio: 'inherit'});
        execSync('pnpm exec husky install', {stdio: 'inherit'});

        const huskyDir = path.join(process.cwd(), '.husky');
        const preCommitHook = path.join(huskyDir, 'pre-commit');

        const preCommitContent = `#!/bin/sh
. "$(dirname "$0")/_/husky.sh"

echo "Running pre-commit hook..."
pnpm exec node /Users/roisusi/Desktop/Projects/TestPOC/Tests/MFE-SCRIPTS/mfe-configs/scripts/update-configs.cjs
`;

        fs.writeFileSync(preCommitHook, preCommitContent.trim());
        fs.chmodSync(preCommitHook, '755');
        console.log(chalk.green('Husky pre-commit hook installed.'));
    } catch (error) {
        console.error(chalk.red('Failed to set up Husky:'), error.message);
        process.exit(1);
    }
};


// Function to add federation to Vite config files
const addFederationToViteConfig = (filePath, mfeName) => {
    const mfeNameCapitalized = mfeName.charAt(0).toUpperCase() + mfeName.slice(1);

    const federationPlugin = `
        federation({
            name: 'remote-${mfeName}',
            filename: 'remote-${mfeName}.js',
            exposes: {
                './Mfe${mfeNameCapitalized}': './src/components/Mfe${mfeNameCapitalized}.tsx',
            },
            shared: ['react', 'react-dom', 'react-router-dom'],
        })
    `;

    const fileContent = `
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import federation from '@originjs/vite-plugin-federation';

// https://vite.dev/config/
export default defineConfig({
    plugins: [react(), ${federationPlugin.trim()}]
});
    `;

    try {
        fs.writeFileSync(filePath, fileContent.trim());
        console.log(chalk.green(`Federation configuration added to ${filePath}.`));
    } catch (error) {
        console.error(chalk.red(`Failed to write federation configuration to ${filePath}:`), error.message);
    }
};

// Function to copy configuration files
const copyConfigFiles = () => {
    const templatesDir = path.join(__dirname, '../templates');

    CONFIG_FILES.forEach((file) => {
        const source = path.join(templatesDir, file);
        const destination = path.join(process.cwd(), file);

        if (!fs.existsSync(source)) {
            console.warn(chalk.red(`Template for ${file} not found in ${templatesDir}`));
            return;
        }

        fs.copyFileSync(source, destination);
        console.log(chalk.green(`Copied ${source} to ${destination}`));
    });
};

// Function to create directories and components
const createDirectories = () => {
    // Create the base directories
    DIRECTORIES.forEach((dir) => {
        fs.mkdirSync(dir, {recursive: true});
        console.log(chalk.green(`Created directory: ${dir}`));
    });

    // Create components files
    const componentsDir = path.join(process.cwd(), 'src', 'components');
    fs.mkdirSync(componentsDir, {recursive: true});

    const templatesDir = path.join(__dirname, '../templates');
    const mfeName = require(path.join(process.cwd(), 'package.json')).name.replace('mfe-', '');
    const mfeNameCapitalized = mfeName.charAt(0).toUpperCase() + mfeName.slice(1);

    const appRootPath = path.join(componentsDir, 'AppRoot.tsx');
    const mfeComponentPath = path.join(componentsDir, `Mfe${mfeNameCapitalized}.tsx`);

    const appRootTemplatePath = path.join(templatesDir, 'AppRoot.tsx');
    const mfeTemplatePath = path.join(templatesDir, 'mfe.tsx');

    // Create AppRoot.tsx
    if (!fs.existsSync(appRootPath)) {
        if (fs.existsSync(appRootTemplatePath)) {
            let appRootContent = fs.readFileSync(appRootTemplatePath, 'utf-8');
            fs.writeFileSync(appRootPath, appRootContent.trim());
            console.log(chalk.green(`Created component: ${appRootPath}`));
        } else {
            console.error(chalk.red(`AppRoot template not found at ${appRootTemplatePath}`));
        }
    } else {
        console.log(chalk.cyan(`Component already exists: ${appRootPath}`));
    }

    // Create Mfe<Name>.tsx
    if (!fs.existsSync(mfeComponentPath)) {
        if (fs.existsSync(mfeTemplatePath)) {
            let mfeContent = fs.readFileSync(mfeTemplatePath, 'utf-8');
            mfeContent = mfeContent.replace(/{new-name}/g, mfeNameCapitalized);
            fs.writeFileSync(mfeComponentPath, mfeContent.trim());
            console.log(chalk.green(`Created component: ${mfeComponentPath}`));
        } else {
            console.error(chalk.red(`MFE template not found at ${mfeTemplatePath}`));
        }
    } else {
        console.log(chalk.cyan(`Component already exists: ${mfeComponentPath}`));
    }
};

// Main setup function
const setupMfe = () => {
    const version = require('../../package.json').version || '1.0.0';
    displayBanner(version);

    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout,
    });

    rl.question(chalk.green('Do you want to proceed with the setup? (y/n): '), (answer) => {
        if (answer.toLowerCase() !== 'y') {
            console.log(chalk.red('Setup aborted by the user.'));
            rl.close();
            process.exit(0);
        }

        console.log(chalk.green('Proceeding with the setup...'));
        rl.close();

        // Check if pnpm is installed
        if (!isCommandAvailable('pnpm')) {
            console.log(chalk.yellow('pnpm is not installed. Installing it globally...'));
            try {
                execSync('npm install -g pnpm', {stdio: 'inherit'});
                console.log(chalk.green('pnpm installed globally.'));
            } catch (error) {
                console.error(chalk.red('Failed to install pnpm globally:', error.message));
                process.exit(1);
            }
        } else {
            console.log(chalk.green('pnpm is already installed.'));
        }

        // Clean directory
        cleanDirectory();

        // Create Vite project
        createViteProject();

        // Initialize Git
        initializeGit();

        // Set up Husky
        setupHusky();

        // Copy configuration files
        console.log(chalk.yellow('Copying configuration files...'));
        copyConfigFiles();

        // Create directories and components
        console.log(chalk.yellow('Creating basic directories and components...'));
        createDirectories();

        // Merge package.json
        const templatesDir = path.join(__dirname, '../templates');
        mergePackageJson(templatesDir);

        // Add federation configuration
        const mfeName = require(path.join(process.cwd(), 'package.json')).name.replace('mfe-', '');
        addFederationToViteConfig(path.join(process.cwd(), 'vite.config.ts'), mfeName);
        addFederationToViteConfig(path.join(process.cwd(), 'vite.dev.config.ts'), mfeName);

        console.log(chalk.bgGreenBright('MFE setup completed successfully!'));
    });
};

setupMfe();

