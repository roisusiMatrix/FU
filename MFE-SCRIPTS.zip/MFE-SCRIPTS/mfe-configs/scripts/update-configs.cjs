#!/usr/bin/env node

const fs = require("fs");
const path = require("path");
const chalk = require("chalk");

// Function to compare dependencies and log changes
const compareDependencies = (remoteBaseDeps, localDeps, type, localBaseDeps) => {
    const changes = {
        added: [],
        removed: [],
        updated: [],
    };

    const updatedDependencies = {...localDeps};

    // Check for added or updated dependencies
    Object.entries(remoteBaseDeps).forEach(([key, version]) => {
        if (!localDeps[key]) {
            changes.added.push({key, version});
            updatedDependencies[key] = version;
        } else if (localDeps[key] !== version) {
            changes.updated.push({key, oldVersion: localDeps[key], newVersion: version});
            updatedDependencies[key] = version;
        }
    });

    // Check for removed dependencies (only those present in local base)
    Object.keys(localDeps).forEach((key) => {
        if (!remoteBaseDeps[key] && localBaseDeps[key]) {
            changes.removed.push({key, version: localDeps[key]});
            delete updatedDependencies[key];
        }
    });

    // Log changes
    changes.added.forEach(({key, version}) =>
        console.log(chalk.green(`[${type}] Added: ${key}@${version}`))
    );
    changes.updated.forEach(({key, oldVersion, newVersion}) =>
        console.log(chalk.yellow(`[${type}] Updated: ${key} from ${oldVersion} to ${newVersion}`))
    );
    changes.removed.forEach(({key, version}) =>
        console.log(chalk.red(`[${type}] Removed: ${key}@${version}`))
    );

    return updatedDependencies;
};

// Function to synchronize `package.base.json` between remote and local
const syncPackageBaseJson = () => {
    const templatesDir = path.join(__dirname, "../templates");
    const remoteBasePath = path.join(templatesDir, "package.base.json");
    const localBasePath = path.join(process.cwd(), "package.base.json");

    if (!fs.existsSync(remoteBasePath)) {
        console.error(chalk.red("Remote package.base.json not found in the templates directory."));
        process.exit(1);
    }

    const remoteBaseJson = JSON.parse(fs.readFileSync(remoteBasePath, "utf-8"));

    // Update local package.base.json if it differs
    let localBaseJson = {};
    if (fs.existsSync(localBasePath)) {
        localBaseJson = JSON.parse(fs.readFileSync(localBasePath, "utf-8"));
        if (JSON.stringify(remoteBaseJson) !== JSON.stringify(localBaseJson)) {
            console.log(chalk.yellow("Local package.base.json differs from the remote version. Updating..."));
            fs.writeFileSync(localBasePath, JSON.stringify(remoteBaseJson, null, 2));
            console.log(chalk.green("Local package.base.json updated."));
        } else {
            console.log(chalk.cyan("Local package.base.json is already up to date."));
        }
    } else {
        console.log(chalk.yellow("Local package.base.json not found. Creating it from the remote version."));
        fs.writeFileSync(localBasePath, JSON.stringify(remoteBaseJson, null, 2));
        console.log(chalk.green("Local package.base.json created."));
    }

    return {remoteBaseJson, localBaseJson};
};

// Function to update `package.json` dependencies
const updatePackageJson = (remoteBaseJson, localBaseJson) => {
    const packageJsonPath = path.join(process.cwd(), "package.json");

    if (!fs.existsSync(packageJsonPath)) {
        console.error(chalk.red("package.json not found in the project root."));
        process.exit(1);
    }

    const packageJson = JSON.parse(fs.readFileSync(packageJsonPath, "utf-8"));

    // Compare and update dependencies
    packageJson.dependencies = compareDependencies(
        remoteBaseJson.dependencies || {},
        packageJson.dependencies || {},
        "Dependencies",
        localBaseJson.dependencies || {}
    );

    // Compare and update devDependencies
    packageJson.devDependencies = compareDependencies(
        remoteBaseJson.devDependencies || {},
        packageJson.devDependencies || {},
        "DevDependencies",
        localBaseJson.devDependencies || {}
    );

    // Ensure `extends` points to `package.base.json`
    packageJson.extends = "./package.base.json";

    fs.writeFileSync(packageJsonPath, JSON.stringify(packageJson, null, 2));
    console.log(chalk.green("package.json updated successfully!"));
};

// Function to copy and check configuration files
const copyConfigFiles = () => {
    const CONFIG_FILES = [
        ".dockerignore",
        ".gitignore",
        ".prettierrc",
        "Dockerfile",
        "Dockerfile-local",
        "eslint.config.js",
        "README.md",
    ];

    const templatesDir = path.join(__dirname, "../templates");
    CONFIG_FILES.forEach((file) => {
        const source = path.join(templatesDir, file);
        const destination = path.join(process.cwd(), file);

        if (!fs.existsSync(source)) {
            console.warn(chalk.red(`Template for ${file} not found in ${templatesDir}`));
            return;
        }

        const sourceContent = fs.readFileSync(source, "utf-8");
        if (fs.existsSync(destination)) {
            const destinationContent = fs.readFileSync(destination, "utf-8");
            if (sourceContent !== destinationContent) {
                console.log(chalk.yellow(`File changed: ${destination}`));
                fs.writeFileSync(destination, sourceContent);
                console.log(chalk.green(`Updated file: ${destination}`));
            } else {
                console.log(chalk.cyan(`No changes in file: ${destination}`));
            }
        } else {
            fs.writeFileSync(destination, sourceContent);
            console.log(chalk.green(`Created file: ${destination}`));
        }
    });
};

// Function to create directories
const createDirectories = () => {
    const DIRECTORIES = [
        "src",
        "src/api",
        "src/assets",
        "src/components",
        "src/data",
        "src/enums",
        "src/hooks",
        "src/infrastructure",
        "src/interfaces",
        "src/models",
        "src/types",
        "src/utils",
    ];

    DIRECTORIES.forEach((dir) => {
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, {recursive: true});
            console.log(chalk.green(`Created directory: ${dir}`));
        } else {
            console.log(chalk.cyan(`Directory already exists: ${dir}`));
        }
    });
};

// Main synchronization function
const syncConfigurations = () => {
    console.log(chalk.green("Starting configuration synchronization..."));

    // Sync and retrieve remote and local base.json
    const {remoteBaseJson, localBaseJson} = syncPackageBaseJson();

    // Update `package.json`
    console.log(chalk.yellow("Updating package.json..."));
    updatePackageJson(remoteBaseJson, localBaseJson);

    // Copy configuration files
    console.log(chalk.yellow("Copying configuration files..."));
    copyConfigFiles();

    // Create directories
    console.log(chalk.yellow("Ensuring directory structure..."));
    createDirectories();

    console.log(chalk.green("Configuration synchronization completed successfully!"));
};

syncConfigurations();
