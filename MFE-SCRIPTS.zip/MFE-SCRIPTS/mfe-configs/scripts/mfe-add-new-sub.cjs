#!/usr/bin/env node

const chalk = require('chalk');
const fs = require('fs');
const path = require('path');
const readline = require('readline');

// Function to convert kebab-case to camelCase
const toCamelCase = (name) => {
    return name.replace(/-([a-z])/g, (match, letter) => letter.toUpperCase());
};

// Function to convert kebab-case to PascalCase
const toPascalCase = (name) => {
    return name
        .replace(/-([a-z])/g, (match, letter) => letter.toUpperCase())
        .replace(/^([a-z])/, (match, letter) => letter.toUpperCase());
};

// Function to copy the API template
const copyApiTemplate = (apiName, templatesDir) => {
    const apiDir = path.join(process.cwd(), 'src', 'api');
    const fileName = `api-${apiName}.ts`;
    const filePath = path.join(apiDir, fileName);

    // Ensure the API directory exists
    if (!fs.existsSync(apiDir)) {
        fs.mkdirSync(apiDir, {recursive: true});
        console.log(chalk.green(`Created directory: ${apiDir}`));
    }

    // Copy the template
    const templatePath = path.join(templatesDir, 'api.ts');
    if (!fs.existsSync(templatePath)) {
        console.error(chalk.red(`Template file api.ts not found in ${templatesDir}`));
        process.exit(1);
    }

    const templateContent = fs.readFileSync(templatePath, 'utf-8');
    const updatedContent = templateContent
        .replace(/\{new-name\}/g, toCamelCase(apiName))
        .replace(/export const \{new-name\}Service/g, `export const ${toCamelCase(apiName)}Service`);

    fs.writeFileSync(filePath, updatedContent);
    console.log(chalk.green(`Created API file: ${filePath}`));
};

// Function to update the index.ts file
const updateIndexFile = (apiName) => {
    const apiDir = path.join(process.cwd(), 'src', 'api');
    const indexPath = path.join(apiDir, 'index.ts');

    // Ensure the index.ts file exists
    if (!fs.existsSync(indexPath)) {
        fs.writeFileSync(indexPath, 'export const api = {};\n');
        console.log(chalk.green(`Created index file: ${indexPath}`));
    }

    // Update the index.ts file
    let indexContent = fs.readFileSync(indexPath, 'utf-8');
    const camelCaseName = toCamelCase(apiName);
    const pascalCaseName = toPascalCase(apiName);
    const newExport = `${camelCaseName}: ${camelCaseName}Service()`;
    const newImport = `import { ${camelCaseName}Service } from './api-${apiName}';`;

    // Add import if not already present
    if (!indexContent.includes(newImport)) {
        indexContent = `${newImport}\n${indexContent}`;
        console.log(chalk.green(`Added import for ${apiName}Service in index.ts`));
    }

    // Add export if not already present
    const exportRegex = /export const api = \{([\s\S]*?)\};/;
    const match = indexContent.match(exportRegex);

    if (match) {
        const existingExports = match[1].trim();

        if (!existingExports.includes(newExport)) {
            const updatedExports = existingExports
                ? `${existingExports},\n  ${newExport}`
                : `  ${newExport}`;

            indexContent = indexContent.replace(
                exportRegex,
                `export const api = {\n${updatedExports}\n};`
            );
            console.log(chalk.green(`Updated exports in index.ts for ${apiName}`));
        } else {
            console.log(chalk.cyan(`API export for ${apiName} already exists in index.ts`));
        }
    } else {
        console.error(chalk.red('Failed to parse index.ts file. Adding a new export block.'));
        indexContent += `\nexport const api = {\n  ${newExport}\n};\n`;
    }

    fs.writeFileSync(indexPath, indexContent);
};

// Main function to add a new API
const addApi = () => {
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout,
    });

    rl.question(chalk.green('Enter the name of the API to add (e.g., "my-api"): '), (apiName) => {
        if (!apiName.trim()) {
            console.log(chalk.red('API name cannot be empty. Exiting...'));
            rl.close();
            return;
        }

        console.log(chalk.green(`Adding API: ${apiName}`));

        const templatesDir = path.join(__dirname, '../templates');

        // Copy the API template
        copyApiTemplate(apiName.trim(), templatesDir);

        // Update the index.ts file
        updateIndexFile(apiName.trim());

        rl.close();
    });
};

addApi();
