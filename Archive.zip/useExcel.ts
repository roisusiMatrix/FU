import * as ExcelJS from 'exceljs'
import { useRef } from 'react'

type UseExcelOptions<T> = {
    dateNumFmt: string
    numberNumFmt: string
    parsedKeys: {
        [K in keyof T]?: (value: T[K], row: T) => string | number | Date
    }
    numFmtKeys: {
        [K in keyof T]?: string
    }
}
type MinimalT = Record<string, unknown>
type Column<T> = ExcelJS.Column & { key: keyof T }

function useExcel<T extends MinimalT>(
    options: Partial<UseExcelOptions<T>> = {}
) {
    const workbookRef = useRef<ExcelJS.Workbook | null>(null)

    const optionsWithDefaults: UseExcelOptions<T> = {
        dateNumFmt: 'dd/mm/yyyy',
        numberNumFmt: '#,##0',
        parsedKeys: {},
        numFmtKeys: {},
        ...options,
    }

    const createWorkbook = () => {
        const workbook = new ExcelJS.Workbook()
        workbookRef.current = workbook
        return workbook
    }

    const addWorksheet = (
        name: string,
        options: Partial<ExcelJS.AddWorksheetOptions> = {}
    ) => {
        if (!workbookRef.current) {
            throw new Error('Workbook not created')
        }
        workbookRef.current.addWorksheet(name, {
            views: [{ rightToLeft: true }],
            ...options,
        })
    }

    const addHeaders = (
        headers: Partial<Column<T>>[],
        worksheetIndexOrName?: string | number
    ) => {
        if (!workbookRef.current) {
            throw new Error('Workbook not created')
        }
        const worksheet = workbookRef.current.getWorksheet(
            worksheetIndexOrName || 1
        )
        if (!worksheet) {
            throw new Error('Worksheet not found')
        }

        worksheet.columns = headers
        worksheet.getColumn('birthday').numFmt = 'dd/mm/yyyy'
    }

    const addRows = (
        rows: Partial<T>[],
        style?: string,
        worksheetIndexOrName?: string | number
    ) => {
        if (!workbookRef.current) {
            throw new Error('Workbook not created')
        }
        const worksheet = workbookRef.current.getWorksheet(
            worksheetIndexOrName || 1
        )
        if (!worksheet) {
            throw new Error('Worksheet not found')
        }

        if (worksheet.columns.length === 0) {
            throw new Error('Headers not added')
        }
        const parsedRows = rows.map((row) =>
            Object.entries(row).reduce((acc, [key, value]) => {
                const formatKey = optionsWithDefaults.parsedKeys[key as keyof T]
                if (formatKey) {
                    return {
                        ...acc,
                        [key]: formatKey(value as T[keyof T], row as T),
                    }
                }

                return { ...acc, [key]: value }
            }, {})
        )
        const sheetsRows = worksheet.addRows(parsedRows, style)
        sheetsRows.forEach((row) => {
            row.eachCell((cell) => {
                const column = worksheet.getColumn(cell.col)
                const key = column.key as keyof T
                const numFtmKey = optionsWithDefaults.numFmtKeys[key]
                if (numFtmKey) {
                    cell.numFmt = numFtmKey
                } else if (cell.type === ExcelJS.ValueType.Date) {
                    cell.numFmt = optionsWithDefaults.dateNumFmt
                } else if (cell.type === ExcelJS.ValueType.Number) {
                    cell.numFmt = optionsWithDefaults.numberNumFmt
                }
            })
        })
    }

    const writeBuffer = async () => {
        if (!workbookRef.current) {
            throw new Error('Workbook not created')
        }
        return workbookRef.current.xlsx.writeBuffer()
    }

    const createBlob = async () => {
        const buffer = await writeBuffer()
        return new Blob([buffer], {
            type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        })
    }

    const download = async (fileName: string) => {
        const blob = await createBlob()
        const url = URL.createObjectURL(blob)
        const link = document.createElement('a')
        link.href = url
        link.download = fileName
        link.click()
        URL.revokeObjectURL(url)
    }

    const clear = () => {
        workbookRef.current = null
    }

    return {
        createWorkbook,
        addWorksheet,
        addHeaders,
        addRows,
        download,
        clear,
        workbookRef,
    }
}

export default useExcel
