@Controller('file-system')
export class FileSystemController {
  @Post('upload-single')
  @UseInterceptors(
    FileInterceptor('file'),
    new FileValidationInterceptorInterceptor(false, [FileType.IMAGE], 1),
  )
  async uploadFile(@UploadedFile() file: Express.Multer.File) {
    if (!file) throw new BadRequestException(`file is required!`);
    return {
      message: 'File received successfully',
    };
  }

  @Post('upload-multiple')
  @UseInterceptors(
    FilesInterceptor('files'),
    new FileValidationInterceptorInterceptor(
      true,
      [FileType.IMAGE],
      24 * 1024 * 1024,
    ),
  )
  async uploadMultipleFiles(@UploadedFiles() files: Express.Multer.File[]) {
    if (!files) throw new BadRequestException(`files are required!`);
    return {
      message: 'Files received successfully',
    };
  }
}
