

# `useExcel` Hook

This React hook helps you create and download Excel files using the `exceljs` library. It provides convenient functions to manage Excel workbooks, worksheets, headers, and rows, as well as utilities for formatting data, all directly from your React components.

### Usage

````tsx
import  useExcel  from  './useExcel'

type  User = {
name: string
age: number
email: string
isMale: boolean
birthday: Date
}

const  users: User[] = [
{
name:  'Alice',
age:  4.21,
isMale:  false,
email:  'alice25@gmail.com',
birthday:  new  Date('1996-02-01'),
},
{
name:  'Bob',
age:  30.12,
isMale:  true,
email:  'bob30@gmail.com',
birthday:  new  Date('1991-01-02'),
},
{
name:  'Charlie',
age:  25434,
isMale:  true,
email:  'charlie35@gmial.com',
birthday:  new  Date('1986-12-12'),
},
]

function  ExcelDownload() {
const  userExcel = useExcel<User>({})
const  handleDownload = async () => {
userExcel.createWorkbook()
userExcel.addWorksheet('Users')
userExcel.addHeaders([
{ header:  'שם', key:  'name' },
{ header:  'גיל', key:  'age' },
{ header:  'דואר אלקטרוני', key:  'email' },
{ header:  'יום הולדת', key:  'birthday' },
{ header:  'זכר', key:  'isMale' },
])
userExcel.addRows(users)
userExcel.download('users.xlsx')
}

return (
<div>
<button  onClick={handleDownload}>Download Excel</button>
</div>
)
}
export  default  ExcelDownload
````

### Options
The hook accepts an optional configuration object to customize the behavior and formatting of Excel files. Here are the available options:

| Option | Type | Default | Description|
| ------------- | ------------ | -------------- | --------------------------------------------------------------------------------------------------------------- |
| `dateNumFmt` | `string` | `dd/mm/yyyy` | The date format used in cells with date values. |
| `numberNumFmt`| `string` | `#,##0` | The number format used in cells with numeric values. |
| `numFmtKeys` | `object` | `{}` | A map of specific keys to custom number formats. Example: `{ price: '$#,##0.00' }` for a currency column. |
| `parsedKeys` | `object` | `{}` | Functions to parse specific key values before inserting them into the worksheet. Can transform values dynamically. |

### `parsedKeys` Example

You can use `parsedKeys` to customize how data is displayed for specific columns:

```tsx
const {
createWorkbook,
addWorksheet,
addHeaders,
addRows,
download,
} = useExcel({
parsedKeys: {
name: (value) => `User: ${value}`, // Prefix name with 'User:'
birthday: (value) => new Date(value).toLocaleDateString(), // Format birthday as a readable string
},
});
````

## Returned Functions

The `useExcel` hook returns a set of utility functions to manage Excel files.

### `createWorkbook`

Creates a new workbook. You must call this function before adding worksheets or other content. It initializes the workbook in memory.

### `addWorksheet`

Adds a worksheet to the current workbook.

- **Arguments:**
  - `name` (`string`): The name of the worksheet.
  - `options` (`Partial<ExcelJS.AddWorksheetOptions>`): Additional options for worksheet configuration.

- **Defaults:**
  - Adds the worksheet with a `rightToLeft` view option.

- **Errors:**
  - Throws an error if the workbook hasn't been created yet.

### `addHeaders`

Defines the headers (columns) for a specific worksheet.

- **Arguments:**
  - `headers` (`Array<Partial<Column<T>>>`): Array of column definitions, where each column has a `header` (name) and `key` (corresponding to the data).
  - `worksheetIndexOrName` (`string | number`): Optional. Worksheet name or index. Defaults to the first worksheet.

- **Errors:**
  - Throws an error if the workbook or worksheet is not found.

### `addRows`

Adds rows of data to a worksheet.

- **Arguments:**
  - `rows` (`Array<Partial<T>>`): An array of data rows, each row is an object matching the column keys.
  - `style` (`string`): Optional. Specifies row style.
  - `worksheetIndexOrName` (`string | number`): Optional. Worksheet name or index. Defaults to the first worksheet.

- **Errors:**
  - Throws an error if no headers have been added.
  - Throws an error if the workbook or worksheet is not found.

- **Formatting:**
  - Automatically applies number/date formatting based on the column type or custom format set in `numFmtKeys`.

### `download`

Downloads the workbook as an Excel file.

- **Arguments:**
  - `fileName` (`string`): The name of the downloaded file (with `.xlsx` extension).

### `clear`

Clears the current workbook from memory, resetting the state of the hook.

### `workbookRef`

Provides direct access to the `ExcelJS.Workbook` instance for advanced manual operations if needed.

## Additional Notes

- This hook abstracts much of the boilerplate involved in generating Excel files, but it also gives flexibility for advanced users who want to manipulate the workbook manually through the `workbookRef`.
- Use the `numFmtKeys` and `parsedKeys` options to control data formatting dynamically, making it easy to format dates, numbers, and other types of data based on your specific requirements.

