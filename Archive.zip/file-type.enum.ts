enum FileType {
    IMAGE = 'image',
    DOCUMENT = 'document',
    VIDEO = 'video',
    AUDIO = 'audio',
    EXCEL = 'excel',
    PDF = 'pdf',
    TEXT = 'text',
    POWERPOINT = 'powerpoint',
  }
  export default FileType;
  
  