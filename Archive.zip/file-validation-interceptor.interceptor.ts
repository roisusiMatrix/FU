import {
    BadRequestException,
    CallHandler,
    ExecutionContext,
    Injectable,
    NestInterceptor,
  } from '@nestjs/common';
  import { Observable } from 'rxjs';
  import FileType from 'src/file-system/enums/file-type.enum';
  import { Request } from 'express';
  import getFileTypeData from 'src/file-system/utils/get-file-type-data';
  
  @Injectable()
  export class FileValidationInterceptorInterceptor implements NestInterceptor {
    constructor(
      private readonly isMultiple: boolean = false, // Specify if it's single or multiple
      private readonly allowedFileTypes?: FileType[],
      private readonly fileSizeLimit?: number, // Optional file size limit in bytes
      private readonly fileCountLimit?: number, // Optional file count limit
    ) {}
  
    intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
      const request = context.switchToHttp().getRequest<Request>();
  
      const files = (
        (this.isMultiple
          ? (request.files ?? [])
          : [request.file]) as Express.Multer.File[]
      ).filter((file: Express.Multer.File | null) => !!file);
  
      this.validateAmountOfFiles(files);
      this.validateFilesSize(files);
      this.validateFilesType(files);
      return next.handle();
    }
  
    private validateFilesType(files: Express.Multer.File[]) {
      const { allowedMimeTypes, allowedExtensions } =
        this.allowedFileTypes.reduce(
          (acc, fileType) => {
            const { mimeTypes, extensions } = getFileTypeData(fileType);
            acc.allowedMimeTypes.push(...mimeTypes);
            acc.allowedExtensions.push(...extensions);
            return acc;
          },
          {
            allowedExtensions: [] as string[],
            allowedMimeTypes: [] as string[],
          },
        );
  
      files.forEach((file) => {
        const ext = file.originalname.slice(file.originalname.lastIndexOf('.'));
  
        if (
          this.allowedFileTypes &&
          (!allowedMimeTypes.includes(file.mimetype) ||
            !allowedExtensions.includes(ext))
        ) {
          throw new BadRequestException(
            `Only ${this.allowedFileTypes.join(', ')} files are allowed!`,
          );
        }
      });
    }
  
    private validateFilesSize(files: Express.Multer.File[]) {
      files.forEach((file) => {
        if (this.fileSizeLimit && file.size > this.fileSizeLimit) {
          throw new BadRequestException(
            `File size must be less than ${this.fileSizeLimit} bytes`,
          );
        }
      });
    }
  
    private validateAmountOfFiles(files: Express.Multer.File[]) {
      if (files.length === 0) {
        throw new BadRequestException(
          this.isMultiple
            ? 'At least one file must be uploaded'
            : 'A file must be uploaded',
        );
      }
  
      if (this.fileCountLimit && files.length > this.fileCountLimit) {
        throw new BadRequestException(
          `Only ${this.fileCountLimit} files are allowed!`,
        );
      }
    }
  }