import FileType from 'src/file-system/enums/file-type.enum';

function getFileTypeData(fileType: FileType) {
  switch (fileType) {
    case FileType.IMAGE:
      return {
        mimeTypes: ['image/jpeg', 'image/png'],
        extensions: ['.jpg', '.png'],
      };
    case FileType.DOCUMENT:
      return {
        mimeTypes: [
          'application/msword',
          'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        ],
        extensions: ['.doc', '.docx'],
      };
    case FileType.VIDEO:
      return {
        mimeTypes: ['video/mp4', 'video/quicktime'],
        extensions: ['.mp4', '.mov'],
      };
    case FileType.AUDIO:
      return {
        mimeTypes: ['audio/mpeg', 'audio/ogg'],
        extensions: ['.mp3', '.ogg'],
      };
    case FileType.EXCEL:
      return {
        mimeTypes: [
          'application/vnd.ms-excel',
          'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        ],
        extensions: ['.xls', '.xlsx'],
      };
    case FileType.PDF:
      return {
        mimeTypes: ['application/pdf'],
        extensions: ['.pdf'],
      };
    case FileType.TEXT:
      return {
        mimeTypes: ['text/plain'],
        extensions: ['.txt'],
      };
    case FileType.POWERPOINT:
      return {
        mimeTypes: [
          'application/vnd.ms-powerpoint',
          'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        ],
        extensions: ['.ppt', '.pptx'],
      };
    default:
      return {
        mimeTypes: [],
        extensions: [],
      };
  }
}

export default getFileTypeData;
